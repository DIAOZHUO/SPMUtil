#ifndef CYTHON_CODE
#define CYTHON_CODE
void calc_NCC(float *m_flat, int m_size[3], float *f_flat, int f_size[3], float *NCC_flat);
#endif